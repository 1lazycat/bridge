/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'ext.same-assets.com',
        pathname: '/**',
      },
    ],
  },
  // Optimize for streaming responses
  experimental: {
    serverActions: {
      // Allow for longer server-side operation
      bodySizeLimit: '5mb',
    },
  },
  // Improve loading performance
  reactStrictMode: true,
  compiler: {
    // Remove console logs in production
    removeConsole: process.env.NODE_ENV === 'production',
  },
};

export default nextConfig;
