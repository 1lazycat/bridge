"use client";

import React, { useState, useEffect, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Clock,
  Share2,
  Link as LinkIcon,
  Copy,
  MessageSquare,
  ArrowLeft,
  MoreHorizontal,
  BookmarkIcon,
  Loader2,
  ChevronDown,
  List,
  Code,
  ThumbsUp,
  ThumbsDown,
  ExternalLink,
  ClipboardCopy
} from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import SearchBox from "@/components/search-box";
import {
  generateMockSearchResponse,
  generateSearchResponse,
  generateMockStreamingSearchResponse,
  generateStreamingSearchResponse,
  type SearchResponse
} from "@/lib/openai";
import { useAuth } from "@/contexts/auth-context";
import { CodeBlock } from "@/components/ui/code-block"; // Updated to use the new CodeBlock component

// Update the typing cursor animation
const TypingCursor = () => (
  <span className="typing-cursor text-perplexity-teal inline-block ml-0.5 -mb-1">|</span>
);

// Generate table of contents from a text
const generateTOC = (text: string) => {
  // Simple regex to extract headings
  const headingRegex = /#{1,3}\s+(.+?)(?=\n|$)/g;
  const headings: {id: string, text: string, level: number}[] = [];

  let match;
  while ((match = headingRegex.exec(text)) !== null) {
    const headingText = match[1].trim();
    const level = match[0].trim().startsWith('###') ? 3 :
                  match[0].trim().startsWith('##') ? 2 : 1;
    const id = headingText.toLowerCase().replace(/[^\w\s]/g, '').replace(/\s+/g, '-');

    headings.push({ id, text: headingText, level });
  }

  return headings;
};

interface ClientSearchPageProps {
  query: string;
}

export default function ClientSearchPage({ query }: ClientSearchPageProps) {
  const router = useRouter();
  const { user, addSearchToHistory } = useAuth();
  const decodedQuery = decodeURIComponent(query);
  const [isLoading, setIsLoading] = useState(true);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedText, setStreamedText] = useState("");
  const [searchResponse, setSearchResponse] = useState<SearchResponse | null>(null);
  const answerContainerRef = useRef<HTMLDivElement>(null);
  const [activeHeading, setActiveHeading] = useState<string | null>(null);
  const [showTOC, setShowTOC] = useState(true);
  const [feedbackGiven, setFeedbackGiven] = useState<'up' | 'down' | null>(null);
  const [copiedSourceIndex, setCopiedSourceIndex] = useState<number | null>(null);
  const [expandedSections, setExpandedSections] = useState<{[key: string]: boolean}>({});

  // Auto-scroll to bottom as text streams in
  useEffect(() => {
    if (isStreaming && answerContainerRef.current) {
      answerContainerRef.current.scrollTop = answerContainerRef.current.scrollHeight;
    }
  }, [streamedText, isStreaming]);

  // Update search history if user is logged in
  useEffect(() => {
    if (user) {
      addSearchToHistory(decodedQuery);
    }
  }, [user, decodedQuery, addSearchToHistory]);

  // Generate search results using streaming
  useEffect(() => {
    const fetchSearchResults = async () => {
      setIsLoading(true);
      setStreamedText("");
      setIsStreaming(true);

      try {
        // Use the streaming mock function instead of actual API call to save on API costs
        // In production, you could use generateStreamingSearchResponse instead
        generateMockStreamingSearchResponse(
          decodedQuery,
          // This callback receives each new chunk of text
          (chunk) => {
            setStreamedText((prev) => prev + chunk);
          },
          // This callback is called when streaming is complete
          (fullResponse) => {
            setSearchResponse(fullResponse);
            setIsStreaming(false);
            setIsLoading(false);
          }
        );
      } catch (error) {
        console.error("Error fetching search results:", error);
        // If streaming fails, fall back to non-streaming mock
        const mockResponse = generateMockSearchResponse(decodedQuery);
        setSearchResponse(mockResponse);
        setStreamedText(mockResponse.answer);
        setIsStreaming(false);
        setIsLoading(false);
      }
    };

    fetchSearchResults();
  }, [decodedQuery]);

  // Track active heading on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (!answerContainerRef.current) return;

      const headings = answerContainerRef.current.querySelectorAll('[id]');
      const scrollPosition = answerContainerRef.current.scrollTop;

      for (let i = headings.length - 1; i >= 0; i--) {
        const heading = headings[i] as HTMLElement;
        if (heading.offsetTop <= scrollPosition + 100) {
          setActiveHeading(heading.id);
          break;
        }
      }
    };

    const container = answerContainerRef.current;
    if (container) {
      container.addEventListener('scroll', handleScroll);
      return () => container.removeEventListener('scroll', handleScroll);
    }
  }, [searchResponse, streamedText]);

  const handleGoBack = () => {
    router.back();
  };

  const handleCopyToClipboard = async () => {
    if (searchResponse?.answer) {
      try {
        await navigator.clipboard.writeText(searchResponse.answer);
        alert("Copied to clipboard!");
      } catch (err) {
        console.error("Failed to copy text: ", err);
      }
    }
  };

  const handleCopySource = async (index: number, url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      setCopiedSourceIndex(index);

      // Reset after 2 seconds
      setTimeout(() => {
        setCopiedSourceIndex(null);
      }, 2000);
    } catch (err) {
      console.error("Failed to copy source URL: ", err);
    }
  };

  const handleToggleSection = (sectionId: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const handleScrollToHeading = (headingId: string) => {
    const heading = document.getElementById(headingId);
    if (heading && answerContainerRef.current) {
      answerContainerRef.current.scrollTo({
        top: heading.offsetTop - 20,
        behavior: 'smooth'
      });
    }
  };

  // Generate TOC from the streamed text
  const tableOfContents = generateTOC(streamedText);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      <header className="border-b border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950">
        <div className="flex items-center px-4 py-2 gap-4">
          <button
            onClick={handleGoBack}
            className="p-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
            aria-label="Go back"
          >
            <ArrowLeft size={20} />
          </button>
          <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
            <Clock size={14} className="mr-1 inline-block" />
            <span>Just now</span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button
              className="p-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              aria-label="More options"
            >
              <MoreHorizontal size={20} />
            </button>
            <button
              className="p-1 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              aria-label="Bookmark this search"
            >
              <BookmarkIcon size={20} />
            </button>
            <Button
              variant="outline"
              size="sm"
              className="flex items-center gap-1 rounded-md border-perplexity-teal text-perplexity-teal hover:bg-perplexity-teal/10 dark:border-perplexity-teal dark:text-perplexity-teal"
              onClick={handleCopyToClipboard}
              aria-label="Share this search"
            >
              <Share2 size={16} />
              <span>Share</span>
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-900 dark:text-white">{decodedQuery}</h1>

        <Tabs defaultValue="answer" className="mb-8">
          <TabsList className="mb-6 bg-transparent border-b border-gray-200 dark:border-gray-800 w-full justify-start gap-8 h-auto rounded-none p-0">
            <TabsTrigger
              value="answer"
              className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-perplexity-teal rounded-none pb-3 text-lg font-medium"
              aria-controls="answer-tab"
            >
              <MessageSquare size={18} />
              <span>Answer</span>
            </TabsTrigger>
            <TabsTrigger
              value="sources"
              className="flex items-center gap-2 data-[state=active]:bg-transparent data-[state=active]:shadow-none data-[state=active]:border-b-2 data-[state=active]:border-perplexity-teal rounded-none pb-3 text-lg font-medium"
              aria-controls="sources-tab"
            >
              <LinkIcon size={18} />
              <span>Sources</span>
              <Badge variant="outline" className="ml-1 h-5 px-1">{searchResponse?.sources.length || 0}</Badge>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="answer" className="mt-0" id="answer-tab" role="tabpanel">
            {isLoading && !streamedText ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="h-12 w-12 text-perplexity-teal animate-spin mb-4" />
                <p className="text-gray-600 dark:text-gray-400 text-lg">Searching for "{decodedQuery}"...</p>
              </div>
            ) : (
              <div className="relative">
                {/* Floating TOC Button */}
                {tableOfContents.length > 0 && (
                  <div className="absolute -left-16 top-0 hidden md:block">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setShowTOC(!showTOC)}
                      className={`rounded-full p-2 ${showTOC ? 'text-perplexity-teal bg-gray-100 dark:bg-gray-800' : 'text-gray-500 dark:text-gray-400'}`}
                      aria-label={showTOC ? "Hide table of contents" : "Show table of contents"}
                    >
                      <List size={18} />
                    </Button>
                  </div>
                )}

                {/* Table of Contents */}
                {tableOfContents.length > 0 && showTOC && (
                  <div className="hidden md:block absolute -left-64 top-10 w-48 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg p-3 shadow-lg max-h-80 overflow-y-auto">
                    <h3 className="font-medium text-sm text-gray-700 dark:text-gray-300 mb-2 uppercase">Contents</h3>
                    <ul className="space-y-1">
                      {tableOfContents.map((heading) => (
                        <li
                          key={heading.id}
                          className={`text-sm ${heading.level > 1 ? 'ml-' + (heading.level - 1) * 2 : ''}`}
                        >
                          <button
                            onClick={() => handleScrollToHeading(heading.id)}
                            className={`hover:text-perplexity-teal text-left block w-full truncate ${
                              activeHeading === heading.id
                                ? 'text-perplexity-teal font-medium'
                                : 'text-gray-600 dark:text-gray-400'
                            }`}
                          >
                            {heading.text}
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Streaming indicator */}
                {isStreaming && (
                  <div className="absolute top-0 right-0">
                    <div className="flex items-center text-xs text-perplexity-teal dark:text-perplexity-teal">
                      <Loader2 className="h-3 w-3 animate-spin mr-1" />
                      <span>Generating...</span>
                    </div>
                  </div>
                )}

                {/* Answer content */}
                <div
                  ref={answerContainerRef}
                  className="prose prose-lg max-w-none dark:prose-invert max-h-[600px] overflow-y-auto pr-4"
                >
                  {/* Format the streamed text with interactive elements */}
                  <div className="whitespace-pre-wrap">
                    {/* Render the text with interactive code blocks and collapsible sections */}
                    {streamedText.split('\n\n').map((paragraph, pIndex) => {
                      // Handle code blocks
                      if (paragraph.startsWith('```') && paragraph.endsWith('```')) {
                        const language = paragraph.split('\n')[0].replace('```', '');
                        const code = paragraph
                          .split('\n')
                          .slice(1, -1)
                          .join('\n');

                        return (
                          <div key={pIndex} className="relative group">
                            <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-6 w-6 rounded-md bg-gray-800/80 hover:bg-gray-700 text-gray-200"
                                onClick={() => {
                                  navigator.clipboard.writeText(code);
                                }}
                                aria-label="Copy code"
                              >
                                <ClipboardCopy size={14} />
                              </Button>
                            </div>
                            <CodeBlock language={language} code={code} />
                          </div>
                        );
                      }

                      // Handle headings for sections
                      if (paragraph.startsWith('## ') || paragraph.startsWith('# ')) {
                        const level = paragraph.startsWith('## ') ? 2 : 1;
                        const headingText = paragraph.replace(/^#+\s+/, '');
                        const headingId = headingText.toLowerCase().replace(/[^\w\s]/g, '').replace(/\s+/g, '-');
                        const sectionId = `section-${headingId}`;
                        const isExpanded = expandedSections[sectionId] !== false; // Default to expanded

                        return (
                          <div key={pIndex} className="mb-4">
                            {level === 1 ? (
                              <h2
                                id={headingId}
                                className="flex items-center text-2xl font-bold cursor-pointer group"
                                onClick={() => handleToggleSection(sectionId)}
                              >
                                {headingText}
                                <ChevronDown
                                  size={20}
                                  className={`ml-2 text-gray-500 dark:text-gray-400 transition-transform ${isExpanded ? '' : 'transform rotate-180'} opacity-0 group-hover:opacity-100`}
                                />
                              </h2>
                            ) : (
                              <h3
                                id={headingId}
                                className="flex items-center text-xl font-bold cursor-pointer group"
                                onClick={() => handleToggleSection(sectionId)}
                              >
                                {headingText}
                                <ChevronDown
                                  size={18}
                                  className={`ml-2 text-gray-500 dark:text-gray-400 transition-transform ${isExpanded ? '' : 'transform rotate-180'} opacity-0 group-hover:opacity-100`}
                                />
                              </h3>
                            )}
                          </div>
                        );
                      }

                      // Regular paragraphs
                      return (
                        <p key={pIndex} className="mb-4">
                          {paragraph}
                        </p>
                      );
                    })}

                    {/* Blinking cursor at the end while streaming */}
                    {isStreaming && <TypingCursor />}
                  </div>

                  {/* Interactive feedback section */}
                  {!isStreaming && (
                    <div className="mt-8 border-t border-gray-200 dark:border-gray-800 pt-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            className={`flex items-center gap-1.5 ${feedbackGiven === 'up' ? 'text-green-600 dark:text-green-500' : 'text-gray-600 dark:text-gray-400'}`}
                            onClick={() => setFeedbackGiven('up')}
                            aria-label="Helpful answer"
                          >
                            <ThumbsUp size={16} />
                            <span>Helpful</span>
                          </Button>

                          <Button
                            variant="ghost"
                            size="sm"
                            className={`flex items-center gap-1.5 ${feedbackGiven === 'down' ? 'text-red-600 dark:text-red-500' : 'text-gray-600 dark:text-gray-400'}`}
                            onClick={() => setFeedbackGiven('down')}
                            aria-label="Unhelpful answer"
                          >
                            <ThumbsDown size={16} />
                            <span>Not helpful</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-wrap gap-2 mt-8 mb-6">
                    {searchResponse?.sources.slice(0, 3).map((source) => (
                      <div key={source.id} className="flex items-center">
                        <Avatar className="h-5 w-5 mr-1">
                          <Image
                            src={source.favicon}
                            alt={source.name}
                            width={20}
                            height={20}
                          />
                        </Avatar>
                        <span className="text-sm text-gray-600 dark:text-gray-400">{source.name}</span>
                      </div>
                    ))}
                    {searchResponse?.sources && searchResponse.sources.length > 3 && (
                      <span className="text-sm text-gray-500 dark:text-gray-400">+{searchResponse.sources.length - 3} sources</span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="sources" id="sources-tab" role="tabpanel">
            <div className="grid grid-cols-1 gap-4">
              {searchResponse?.sources.map((source, index) => (
                <div
                  key={source.id}
                  className="flex items-start gap-3 p-4 rounded-lg border border-gray-200 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-900 transition-colors"
                >
                  <Avatar className="h-6 w-6 mt-1">
                    <Image
                      src={source.favicon}
                      alt={source.name}
                      width={24}
                      height={24}
                    />
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900 dark:text-white">{source.name}</h3>
                    <a
                      href={source.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-blue-600 dark:text-blue-400 hover:underline break-all hover:text-blue-800 dark:hover:text-blue-300 flex items-center gap-1"
                      aria-label={`Visit ${source.name}`}
                    >
                      {source.url}
                      <ExternalLink size={12} />
                    </a>
                    {source.description && (
                      <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">{source.description}</p>
                    )}
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                    onClick={() => handleCopySource(index, source.url)}
                    aria-label="Copy URL"
                  >
                    {copiedSourceIndex === index ? (
                      <span className="text-xs text-green-600 dark:text-green-500">Copied</span>
                    ) : (
                      <ClipboardCopy size={16} />
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-12">
          <h2 className="text-lg font-medium mb-3 text-gray-900 dark:text-white">Related Questions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {[
              `What are the benefits of ${decodedQuery}?`,
              `How does ${decodedQuery} work?`,
              `When was ${decodedQuery} first developed?`,
              `Who are the main experts on ${decodedQuery}?`,
            ].map((question, i) => (
              <Button
                key={i}
                variant="outline"
                className="h-auto py-2 px-4 justify-start font-normal border-gray-200 dark:border-gray-800 text-gray-800 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-900"
                onClick={() => router.push(`/search/${encodeURIComponent(question)}/`)}
              >
                {question}
              </Button>
            ))}
          </div>
        </div>

        <div className="mt-16 mb-8">
          <div className="max-w-xl mx-auto">
            <SearchBox />
          </div>
        </div>
      </main>
    </div>
  );
}
