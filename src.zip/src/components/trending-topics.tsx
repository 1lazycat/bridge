import React from "react";
import { Card } from "./ui/card";
import Image from "next/image";
import Link from "next/link";

interface TopicCard {
  id: string;
  title: string;
  description: string;
  image: string;
  author: {
    name: string;
    avatar: string;
  };
  link: string;
}

const trendingTopics: TopicCard[] = [
  {
    id: "1",
    title: "March Madness is here",
    description: "See the latest bracket, odds, scores, and stats",
    image: "https://ext.same-assets.com/3336398295/415770555.jpeg",
    author: {
      name: "stephenhoban",
      avatar: "https://ext.same-assets.com/3171832455/261186554.jpeg",
    },
    link: "/sports/ncaam",
  },
  {
    id: "2",
    title: "France Ramps Up Nuclear Capability",
    description: "Based on reports from Politico, France is set to reopen its fourth nuclear-capable air base at Luxeuil-Saint-Sauveur",
    image: "https://ext.same-assets.com/1595895707/2663154659.jpeg",
    author: {
      name: "stephenhoban",
      avatar: "https://ext.same-assets.com/3171832455/261186554.jpeg",
    },
    link: "/page/france-ramps-up-nuclear-capabi-ILFSwv0HQm.0T4WvfpE0cQ",
  },
  {
    id: "3",
    title: "Suspect Surrenders after CIA Standoff",
    description: "Based on reports from Fox News, an armed suspect surrendered to police after an hours-long standoff near CIA headquarters",
    image: "https://ext.same-assets.com/1068499371/243495350.jpeg",
    author: {
      name: "dailyed",
      avatar: "https://ext.same-assets.com/2995725654/2300223320.jpeg",
    },
    link: "/page/suspect-surrenders-after-cia-s-uXR3k97gR_aoFa57uHIGUA",
  },
];

export default function TrendingTopics() {
  return (
    <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {trendingTopics.map((topic) => (
        <Link href={topic.link} key={topic.id} className="block group">
          <Card className="overflow-hidden border h-full hover:shadow-md transition-shadow">
            <div className="relative h-44 w-full">
              <Image
                src={topic.image}
                alt={topic.title}
                fill
                style={{ objectFit: "cover" }}
              />
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-gray-800 group-hover:text-perplexity-teal">
                {topic.title}
              </h3>
              <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                {topic.description}
              </p>
              <div className="flex items-center mt-3">
                <div className="h-6 w-6 rounded-full overflow-hidden relative">
                  <Image
                    src={topic.author.avatar}
                    alt={topic.author.name}
                    fill
                    style={{ objectFit: "cover" }}
                  />
                </div>
                <span className="ml-2 text-sm text-gray-600">
                  {topic.author.name}
                </span>
              </div>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  );
}
