"use client";

import * as React from "react";
import { ThemeProvider as NextThemesProvider } from "next-themes";
import { type ThemeProviderProps } from "next-themes/dist/types";

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  // Add a class to handle transitions when theme changes
  React.useEffect(() => {
    const handleThemeChange = () => {
      // Add transition class
      document.documentElement.classList.add('dark-mode-transition');

      // Remove class after transitions complete
      const timeout = setTimeout(() => {
        document.documentElement.classList.remove('dark-mode-transition');
      }, 300);

      return () => clearTimeout(timeout);
    };

    // Listen for theme changes
    window.addEventListener('themeChange', handleThemeChange);

    return () => {
      window.removeEventListener('themeChange', handleThemeChange);
    };
  }, []);

  return (
    <NextThemesProvider
      {...props}
      onThemeChange={() => window.dispatchEvent(new Event('themeChange'))}
    >
      {children}
    </NextThemesProvider>
  );
}
