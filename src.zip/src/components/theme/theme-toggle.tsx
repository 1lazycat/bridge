"use client";

import * as React from "react";
import { Moon, Sun } from "lucide-react";
import { useTheme } from "next-themes";

import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function ThemeToggle() {
  const { setTheme, theme, resolvedTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);

  // Only show the toggle after mounting to avoid hydration mismatch
  React.useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) {
    return (
      <Button
        variant="ghost"
        size="icon"
        className="rounded-full h-9 w-9 border border-transparent text-gray-500 dark:text-gray-400 opacity-70"
        aria-label="Loading theme toggle"
      >
        <div className="h-5 w-5 animate-pulse bg-gray-300 dark:bg-gray-700 rounded-full" />
      </Button>
    );
  }

  // Use resolvedTheme to ensure we use the correct icons according to the actual display mode
  const isDark = resolvedTheme === "dark";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="rounded-full h-9 w-9 border hover:border-gray-300 dark:hover:border-gray-700 focus:outline-hidden focus-visible:ring-2 focus-visible:ring-perplexity-teal focus-visible:ring-offset-2 dark:focus-visible:ring-offset-gray-950"
          aria-label="Toggle theme"
        >
          {isDark ? (
            <Moon className="h-5 w-5 text-gray-300" />
          ) : (
            <Sun className="h-5 w-5 text-perplexity-teal" />
          )}
          <span className="sr-only">Toggle theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="font-medium">
        <DropdownMenuItem
          onClick={() => setTheme("light")}
          className="cursor-pointer flex items-center gap-2"
          aria-label="Light theme"
          data-state={theme === "light" ? "checked" : "unchecked"}
        >
          <Sun className="h-4 w-4" />
          <span>Light</span>
          {theme === "light" && <span className="ml-auto text-perplexity-teal">✓</span>}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("dark")}
          className="cursor-pointer flex items-center gap-2"
          aria-label="Dark theme"
          data-state={theme === "dark" ? "checked" : "unchecked"}
        >
          <Moon className="h-4 w-4" />
          <span>Dark</span>
          {theme === "dark" && <span className="ml-auto text-perplexity-teal">✓</span>}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => setTheme("system")}
          className="cursor-pointer flex items-center gap-2"
          aria-label="System theme"
          data-state={theme === "system" ? "checked" : "unchecked"}
        >
          <span className="h-4 w-4 flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12.25 4.75H3.75C3.33579 4.75 3 5.08579 3 5.5V10.5C3 10.9142 3.33579 11.25 3.75 11.25H12.25C12.6642 11.25 13 10.9142 13 10.5V5.5C13 5.08579 12.6642 4.75 12.25 4.75Z"
                stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 11.25V13.25M5.75 13.25H10.25" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M13 8H14.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M1.5 8H3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M8 2.75V4.75" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </span>
          <span>System</span>
          {theme === "system" && <span className="ml-auto text-perplexity-teal">✓</span>}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
