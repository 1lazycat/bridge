"use client";

import React from "react";
import Sidebar from "../sidebar";

interface MainLayoutProps {
  children: React.ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 transition-colors">
      <Sidebar />
      <main className="flex-1 pl-60">
        {children}
      </main>
    </div>
  );
}
