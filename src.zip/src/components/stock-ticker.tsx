import React from "react";
import Link from "next/link";
import { TrendingUp, TrendingDown } from "lucide-react";

interface StockTickerItem {
  symbol: string;
  price: string;
  change: string;
  changePercent: string;
  isPositive: boolean;
  link: string;
}

const stockItems: StockTickerItem[] = [
  {
    symbol: "GOOGL",
    price: "162.57",
    change: "-1.32",
    changePercent: "-0.81%",
    isPositive: false,
    link: "/search/new?q=$GOOGL&source=homepage_widget",
  },
  {
    symbol: "Bitcoin",
    price: "84,066.00",
    change: "-2,800.23",
    changePercent: "-3.23%",
    isPositive: false,
    link: "/search/new?q=$BTCUSD&source=homepage_widget",
  },
  {
    symbol: "AAPL",
    price: "172.28",
    change: "+1.46",
    changePercent: "+0.85%",
    isPositive: true,
    link: "/search/new?q=$AAPL&source=homepage_widget",
  },
];

export default function StockTicker() {
  return (
    <div className="flex flex-wrap gap-2 mt-4">
      {stockItems.map((stock) => (
        <Link
          key={stock.symbol}
          href={stock.link}
          className="inline-flex items-center border rounded-md px-3 py-1.5 hover:bg-gray-50 transition-colors text-sm"
        >
          <div className="flex flex-col">
            <span className="font-medium">{stock.symbol}</span>
            <span className="text-gray-500 text-xs">{stock.price}</span>
          </div>
          <div className={`ml-3 flex items-center ${
            stock.isPositive ? 'text-green-600' : 'text-red-600'
          }`}>
            {stock.isPositive ? (
              <TrendingUp size={16} className="mr-1" />
            ) : (
              <TrendingDown size={16} className="mr-1" />
            )}
            <span>{stock.changePercent}</span>
          </div>
        </Link>
      ))}
    </div>
  );
}
