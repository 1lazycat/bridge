"use client";

import React, { useEffect, useState } from 'react';
import { ClipboardCopy, Check } from 'lucide-react';
import { Button } from './button';
import Prism from 'prismjs';

// Import base Prism styles (needed for highlighting to work)
import 'prismjs/themes/prism.css';
// Import additional languages
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-java';
import 'prismjs/components/prism-c';
import 'prismjs/components/prism-cpp';
import 'prismjs/components/prism-csharp';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-yaml';
import 'prismjs/components/prism-sql';
import 'prismjs/components/prism-go';
import 'prismjs/components/prism-rust';
import 'prismjs/components/prism-php';
import 'prismjs/components/prism-ruby';

interface CodeBlockProps {
  code: string;
  language: string;
  lineNumbers?: boolean;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({
  code,
  language,
  lineNumbers = false
}) => {
  const [copied, setCopied] = useState(false);
  const normalizedLanguage = normalizeLanguage(language);

  // Format the code for proper display
  useEffect(() => {
    if (typeof window !== 'undefined') {
      Prism.highlightAll();
    }
  }, [code, language]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="relative group my-4 rounded-lg overflow-hidden bg-gray-100 dark:bg-gray-800">
      <div className="absolute top-0 right-0 flex items-center gap-1 p-2 z-10">
        {normalizedLanguage && (
          <div className="bg-gray-200 dark:bg-gray-700 px-2 py-1 text-xs rounded-md text-gray-700 dark:text-gray-300 font-mono">
            {normalizedLanguage}
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={copyToClipboard}
          className="h-7 w-7 rounded-md bg-gray-700/80 hover:bg-gray-600 text-gray-200 opacity-0 group-hover:opacity-100 transition-opacity focus:opacity-100"
          aria-label="Copy code"
        >
          {copied ? <Check size={14} className="text-green-400" /> : <ClipboardCopy size={14} />}
        </Button>
      </div>

      <pre className={`p-4 text-gray-800 dark:text-gray-100 text-sm overflow-x-auto ${lineNumbers ? 'line-numbers' : ''}`}>
        <code className={`language-${normalizedLanguage || 'plaintext'}`}>
          {code}
        </code>
      </pre>
    </div>
  );
};

// Helper function to normalize language names
function normalizeLanguage(language: string): string {
  language = language.toLowerCase().trim();

  // Map common language names to Prism's supported languages
  const languageMap: Record<string, string> = {
    'js': 'javascript',
    'ts': 'typescript',
    'jsx': 'jsx',
    'tsx': 'tsx',
    'py': 'python',
    'rb': 'ruby',
    'sh': 'bash',
    'shell': 'bash',
    'yml': 'yaml',
    'csharp': 'cs',
    'c#': 'csharp'
  };

  return languageMap[language] || language;
}
