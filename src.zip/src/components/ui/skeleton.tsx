import { cn } from "@/lib/utils";

interface SkeletonProps extends React.HTMLAttributes<HTMLDivElement> {
  /**
   * Specifies if the skeleton should pulse with animation
   */
  pulse?: boolean;
}

export function Skeleton({
  className,
  pulse = true,
  ...props
}: SkeletonProps) {
  return (
    <div
      className={cn(
        "rounded-md bg-gray-200 dark:bg-gray-800",
        pulse && "animate-pulse",
        className
      )}
      {...props}
    />
  );
}

export function TextLineSkeleton({
  width = "100%",
  height = "1rem",
  className,
  ...props
}: {
  width?: string | number;
  height?: string | number;
} & SkeletonProps) {
  const widthStyle = typeof width === 'number' ? `${width}px` : width;
  const heightStyle = typeof height === 'number' ? `${height}px` : height;

  return (
    <Skeleton
      style={{ width: widthStyle, height: heightStyle }}
      className={cn("my-2", className)}
      {...props}
    />
  );
}

export function ParagraphSkeleton({
  lines = 4,
  lastLineWidth = "60%",
  className,
  ...props
}: {
  lines?: number;
  lastLineWidth?: string | number;
} & SkeletonProps) {
  const linesArray = Array.from({ length: lines });

  return (
    <div className={cn("space-y-2", className)} {...props}>
      {linesArray.map((_, i) => (
        <TextLineSkeleton
          key={i}
          width={i === lines - 1 ? lastLineWidth : "100%"}
        />
      ))}
    </div>
  );
}

export function CardSkeleton({
  className,
  ...props
}: SkeletonProps) {
  return (
    <div className={cn("rounded-lg border border-gray-200 dark:border-gray-800 p-4", className)} {...props}>
      <Skeleton className="h-6 w-1/3 mb-4" />
      <div className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-2/3" />
      </div>
    </div>
  );
}

export function SearchResultSkeleton() {
  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <TextLineSkeleton height="2rem" />
        <ParagraphSkeleton lines={3} />
      </div>

      <div className="space-y-2">
        <TextLineSkeleton width="40%" height="1.5rem" />
        <ParagraphSkeleton lines={5} />
      </div>

      <div className="space-y-2">
        <TextLineSkeleton width="35%" height="1.5rem" />
        <div className="rounded-lg bg-gray-100 dark:bg-gray-800 p-4">
          <ParagraphSkeleton lines={3} pulse={false} className="bg-gray-300 dark:bg-gray-700" />
        </div>
      </div>

      <div className="space-y-2">
        <TextLineSkeleton width="45%" height="1.5rem" />
        <ParagraphSkeleton lines={2} />
      </div>

      <div className="flex gap-2 pt-4">
        <Skeleton className="w-24 h-6 rounded-full" />
        <Skeleton className="w-24 h-6 rounded-full" />
        <Skeleton className="w-24 h-6 rounded-full" />
      </div>
    </div>
  );
}

export function SourceSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 5 }).map((_, i) => (
        <div
          key={i}
          className="flex items-start gap-3 p-4 rounded-lg border border-gray-200 dark:border-gray-800"
        >
          <Skeleton className="w-6 h-6 rounded-full shrink-0" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-5 w-1/4" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-full" />
          </div>
        </div>
      ))}
    </div>
  );
}
