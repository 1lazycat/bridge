"use client";

import React from "react";
import Link from "next/link";

interface LogoProps {
  className?: string;
  fill?: string;
  width?: number;
  height?: number;
}

export function PerplexityLogo({ className, fill = "#2f6975", width = 32, height = 32 }: LogoProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={width}
      height={height}
      viewBox="0 0 32 32"
      className={className}
      fill="none"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M16 7L7 16L16 25L25 16L16 7ZM25 16V7H16M7 16V25H16"
        stroke={fill}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function Logo({ className }: { className?: string }) {
  return (
    <Link href="/" className={`flex items-center space-x-2 ${className || ""}`}>
      <PerplexityLogo />
      <span className="text-perplexity-darkTeal font-medium text-xl">perplexity</span>
    </Link>
  );
}
