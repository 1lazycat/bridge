"use client";

import React, { useEffect, useState } from "react";
import MainLayout from "@/components/layout/main-layout";
import SearchBox from "@/components/search-box";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar } from "@/components/ui/avatar";
import Image from "next/image";
import Link from "next/link";

// Sample trending topics
const trendingTopics = [
  {
    id: "1",
    title: "March Madness is here",
    description: "See the latest bracket, odds, scores, and stats",
    image: "https://ext.same-assets.com/1798230729/1218878156.png",
    author: "stephenhoban",
  },
  {
    id: "2",
    title: "France Ramps Up Nuclear Capability",
    description: "Based on reports from Politico, France is set to reopen its fourth nuclear-powered aircraft carrier",
    image: "https://ext.same-assets.com/3515937045/3120916060.png",
    author: "stephenhoban",
  },
  {
    id: "3",
    title: "Suspect Surrenders after CIA Standoff",
    description: "Based on reports from Fox News, an armed suspect surrendered to police",
    image: "https://ext.same-assets.com/2688594803/3120916060.png",
    author: "dailyed",
  },
];

// Sample stock data
const stockData = [
  { symbol: "GOOGL", name: "Google", price: 162.57, change: -0.81 },
  { symbol: "Bitcoin", name: "BTC", price: 84066.00, change: -3.23 },
  { symbol: "AAPL", name: "Apple", price: 172.28, change: 0.85 },
];

export default function Home() {
  const [demoQuery, setDemoQuery] = useState("");

  useEffect(() => {
    const targetText = "What is artificial intelligence?";
    let index = 0;

    // Only run the demo typing effect once when the component mounts
    const typingInterval = setInterval(() => {
      if (index < targetText.length) {
        setDemoQuery(targetText.substring(0, index + 1));
        index++;
      } else {
        clearInterval(typingInterval);
      }
    }, 100);

    return () => clearInterval(typingInterval);
  }, []);

  return (
    <MainLayout>
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-6">
            What do you want to know?
          </h1>
          <div className="max-w-3xl mx-auto">
            <SearchBox demoQuery={demoQuery} />
          </div>
        </div>

        <div className="mb-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {stockData.map((stock) => (
              <div key={stock.symbol} className="p-3 border rounded-lg bg-white shadow-xs">
                <div className="flex justify-between items-center">
                  <div>
                    <div className="font-medium">{stock.symbol}</div>
                    <div className="text-gray-700">{stock.price.toFixed(2)}</div>
                  </div>
                  <div className={`flex items-center ${stock.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {stock.change >= 0 ? '↑' : '↓'} {Math.abs(stock.change)}%
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {trendingTopics.map((topic) => (
            <Card key={topic.id} className="overflow-hidden hover:shadow-md transition-shadow">
              <div className="h-48 bg-gray-200 relative">
                <Image
                  src={topic.image}
                  alt={topic.title}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-2">{topic.title}</h3>
                <p className="text-gray-600 text-sm mb-4">{topic.description}</p>
                <div className="flex items-center">
                  <Avatar className="h-6 w-6 mr-2">
                    <div className="bg-perplexity-teal text-white text-xs flex items-center justify-center w-full h-full rounded-full">
                      {topic.author.substring(0, 1).toUpperCase()}
                    </div>
                  </Avatar>
                  <span className="text-sm text-gray-500">{topic.author}</span>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </MainLayout>
  );
}
