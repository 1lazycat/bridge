# Perplexity AI Clone

This is a UI clone of [Perplexity AI](https://www.perplexity.ai) built with Next.js 15, React 19, and Tailwind CSS. The project demonstrates a modern UI implementation with typeahead search functionality similar to Perplexity's interface.

## Features

- **Modern UI**: Clean design using Tailwind CSS and shadcn/ui components
- **Search with Typeahead**: Real-time search suggestions while typing
- **Interactive Search Results**: Tabbed interface showing answers and sources
- **Trending Topics**: Display of current popular search topics
- **Stock Ticker**: Real-time(simulated) stock price display
- **Responsive Design**: Works on desktop and mobile devices

## Pages

- **Home**: Main landing page with search functionality
- **Discover**: Content discovery with categorized tabs
- **Spaces**: Placeholder for collaborative spaces (coming soon)
- **Library**: Placeholder for saved content (coming soon)
- **Search Results**: Dynamic search results page based on query

## Technologies Used

- **Next.js 15**: React framework with server and client components
- **React 19**: Latest React for UI development
- **Tailwind CSS**: For styling
- **shadcn/ui**: Reusable UI components
- **Framer Motion**: For animations in search typeahead
- **Lucide Icons**: For icon components

## Getting Started

1. Clone the repository
2. Install dependencies: `bun install`
3. Run the development server: `bun run dev`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Build for Production

```bash
bun run build
```

## Notes

This is a UI clone for educational purposes and doesn't implement the actual AI functionality of Perplexity. The search results are mocked to demonstrate the interface design.

## License

MIT
