import React from "react";
import MainLayout from "@/components/layout/main-layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Globe, Lightbulb, BarChart, Palette, Trophy, Tv, X } from "lucide-react";
import Link from "next/link";
import Image from "next/image";
import Footer from "@/components/footer";

const categories = [
  { id: "top", name: "Top", icon: <Lightbulb size={18} /> },
  { id: "tech", name: "Tech & Science", icon: <Globe size={18} /> },
  { id: "finance", name: "Finance", icon: <BarChart size={18} /> },
  { id: "arts", name: "Arts & Culture", icon: <Palette size={18} /> },
  { id: "sports", name: "Sports", icon: <Trophy size={18} /> },
  { id: "entertainment", name: "Entertainment", icon: <Tv size={18} /> },
];

// These are the same news stories used in the trending-topics component
const newsStories = [
  {
    id: "1",
    title: "Dolphins Greet Returning Astronauts",
    description: "As reported by People and Yahoo News, NASA astronauts Butch Wilmore and Suni Williams were greeted by a pod of curious dolphins upon their return to Earth on March 18, 2025, after spending nine months in space due to unexpected delays.",
    image: "https://ext.same-assets.com/2311891834/369066598.jpeg",
    author: {
      name: "stephenhoban",
      avatar: "https://ext.same-assets.com/3171832455/261186554.jpeg",
    },
    link: "/page/dolphins-greet-returning-astro-n8b32ixZQuGySiG.zOZ9YA",
  },
  {
    id: "2",
    title: "France Ramps Up Nuclear Capability",
    description: "Based on reports from Politico, France is set to reopen its fourth nuclear-capable air base at Luxeuil-Saint-Sauveur, investing 1.5 billion to host advanced Rafale F5 fighter jets and ASN4G hypersonic nuclear missiles by 2035, marking a significant expansion of the country's nuclear deterrent capabilities.",
    image: "https://ext.same-assets.com/1595895707/2663154659.jpeg",
    author: {
      name: "stephenhoban",
      avatar: "https://ext.same-assets.com/3171832455/261186554.jpeg",
    },
    link: "/page/france-ramps-up-nuclear-capabi-ILFSwv0HQm.0T4WvfpE0cQ",
  },
  {
    id: "3",
    title: "Judge Blocks EPA's Termination of Grants",
    description: "As reported by CBS News, a federal judge has temporarily blocked the Environmental Protection Agency's attempt to cancel more than $20 billion in climate grants awarded during the Biden administration, marking a significant setback for the Trump administration's efforts to roll back climate initiatives.",
    image: "https://ext.same-assets.com/1068499371/243495350.jpeg",
    author: {
      name: "dailyed",
      avatar: "https://ext.same-assets.com/2995725654/2300223320.jpeg",
    },
    link: "/page/judge-blocks-epa-s-termination-GxljauweTYe36oHJUxk6PA",
  },
  {
    id: "4",
    title: "Suspect Surrenders after CIA Standoff",
    description: "Based on reports from Fox News, an armed suspect surrendered to police after an hours-long standoff near CIA headquarters in McLean, Virginia on March 19, 2025, prompting a heavy law enforcement response and temporary road closures in the area.",
    image: "https://ext.same-assets.com/1068499371/243495350.jpeg",
    author: {
      name: "dailyed",
      avatar: "https://ext.same-assets.com/2995725654/2300223320.jpeg",
    },
    link: "/page/suspect-surrenders-after-cia-s-uXR3k97gR_aoFa57uHIGUA",
  },
];

export default function DiscoverPage() {
  return (
    <MainLayout>
      <div className="flex flex-col min-h-screen">
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center mb-6">
            <Globe size={24} className="mr-3 text-perplexity-teal" />
            <h1 className="text-3xl font-semibold">Discover</h1>
          </div>

          <Tabs defaultValue="top" className="mb-8">
            <TabsList className="flex gap-1 bg-transparent h-auto p-1 overflow-x-auto">
              {categories.map((category) => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="flex items-center gap-2 py-2 px-3 data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-md"
                >
                  {category.icon}
                  <span>{category.name}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            <TabsContent value="top" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="overflow-hidden h-full border-0 shadow-sm rounded-xl">
                  <div className="relative h-80 w-full">
                    <Image
                      src={newsStories[0].image}
                      alt={newsStories[0].title}
                      fill
                      style={{ objectFit: "cover" }}
                    />
                  </div>
                  <div className="p-5">
                    <h2 className="text-xl font-semibold">{newsStories[0].title}</h2>
                    <p className="text-gray-600 mt-2">{newsStories[0].description}</p>
                    <div className="flex items-center mt-4">
                      <div className="h-6 w-6 rounded-full overflow-hidden relative">
                        <Image
                          src={newsStories[0].author.avatar}
                          alt={newsStories[0].author.name}
                          fill
                          style={{ objectFit: "cover" }}
                        />
                      </div>
                      <span className="ml-2 text-sm text-gray-600">
                        {newsStories[0].author.name}
                      </span>
                    </div>
                  </div>
                </Card>

                <div className="grid grid-cols-1 gap-6">
                  {newsStories.slice(1).map((story) => (
                    <Link href={story.link} key={story.id} className="block">
                      <Card className="overflow-hidden border hover:shadow-md transition-shadow">
                        <div className="flex flex-col md:flex-row h-full">
                          <div className="relative h-40 md:h-auto md:w-2/5">
                            <Image
                              src={story.image}
                              alt={story.title}
                              fill
                              style={{ objectFit: "cover" }}
                            />
                          </div>
                          <div className="p-4 md:w-3/5">
                            <h3 className="font-semibold text-gray-800">{story.title}</h3>
                            <p className="text-sm text-gray-600 mt-1 line-clamp-2">
                              {story.description}
                            </p>
                            <div className="flex items-center mt-3">
                              <div className="h-6 w-6 rounded-full overflow-hidden relative">
                                <Image
                                  src={story.author.avatar}
                                  alt={story.author.name}
                                  fill
                                  style={{ objectFit: "cover" }}
                                />
                              </div>
                              <span className="ml-2 text-sm text-gray-600">
                                {story.author.name}
                              </span>
                            </div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              </div>
            </TabsContent>

            {categories.slice(1).map((category) => (
              <TabsContent key={category.id} value={category.id} className="mt-6">
                <div className="text-center py-20">
                  <h3 className="text-lg font-medium text-gray-600">Content for {category.name} would be shown here</h3>
                </div>
              </TabsContent>
            ))}
          </Tabs>

          <Card className="border p-6 mb-8 relative">
            <button className="absolute top-3 right-3 hover:bg-gray-100 p-1 rounded-full">
              <X size={18} className="text-gray-500" />
            </button>
            <h2 className="font-semibold mb-4">Make it yours</h2>
            <p className="text-gray-600 mb-6">
              Select topics and interests to customize your Discover experience
            </p>

            <div className="flex flex-wrap gap-2 mb-6">
              {categories.slice(1).map((category) => (
                <Badge
                  key={category.id}
                  variant="outline"
                  className="px-3 py-1 cursor-pointer hover:bg-gray-50 flex items-center gap-2"
                >
                  {category.icon}
                  <span>{category.name}</span>
                </Badge>
              ))}
            </div>

            <Button className="w-full md:w-auto bg-perplexity-teal hover:bg-perplexity-darkTeal">
              Save Interests
            </Button>
          </Card>
        </main>

        <Footer />
      </div>
    </MainLayout>
  );
}
