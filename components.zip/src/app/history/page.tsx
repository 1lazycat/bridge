"use client";

import React from "react";
import { useRouter } from "next/navigation";
import MainLayout from "@/components/layout/main-layout";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import { Search, Clock, X, Trash2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function HistoryPage() {
  const router = useRouter();
  const { user, searchHistory, clearSearchHistory } = useAuth();

  // Redirect if not logged in
  React.useEffect(() => {
    if (!user) {
      router.push("/sign-in");
    }
  }, [user, router]);

  if (!user) {
    return null;
  }

  // Group search history by date
  const groupedHistory = searchHistory.reduce(
    (acc, item) => {
      const date = new Date(item.timestamp);
      const today = new Date();
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);

      const isToday =
        date.getDate() === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear();

      const isYesterday =
        date.getDate() === yesterday.getDate() &&
        date.getMonth() === yesterday.getMonth() &&
        date.getFullYear() === yesterday.getFullYear();

      let key;
      if (isToday) {
        key = "Today";
      } else if (isYesterday) {
        key = "Yesterday";
      } else {
        key = date.toLocaleDateString("en-US", {
          month: "long",
          day: "numeric",
          year: "numeric",
        });
      }

      if (!acc[key]) {
        acc[key] = [];
      }
      acc[key].push(item);
      return acc;
    },
    {} as Record<string, typeof searchHistory>
  );

  // Sort the groupedHistory keys so they show up in the correct order
  const sortedGroupKeys = Object.keys(groupedHistory).sort((a, b) => {
    if (a === "Today") return -1;
    if (b === "Today") return 1;
    if (a === "Yesterday") return -1;
    if (b === "Yesterday") return 1;
    return 0;
  });

  return (
    <MainLayout>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Search History</h1>
          {searchHistory.length > 0 && (
            <Button
              variant="outline"
              className="text-red-500 border-red-500 hover:bg-red-50 dark:hover:bg-red-950 dark:text-red-400 dark:border-red-400"
              onClick={clearSearchHistory}
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Clear History
            </Button>
          )}
        </div>

        {searchHistory.length === 0 ? (
          <div className="text-center py-16">
            <Search className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <h2 className="text-xl font-medium text-gray-700 dark:text-gray-300 mb-2">No search history yet</h2>
            <p className="text-gray-500 dark:text-gray-400 mb-4">Your search history will appear here</p>
            <Button
              className="bg-perplexity-teal hover:bg-perplexity-darkTeal"
              onClick={() => router.push("/")}
            >
              Start Searching
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {sortedGroupKeys.map((date) => (
              <div key={date}>
                <h2 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">{date}</h2>
                <div className="space-y-2">
                  {groupedHistory[date].map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center p-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors"
                    >
                      <Search className="h-4 w-4 text-gray-500 dark:text-gray-400 mr-3" />
                      <div className="flex-grow">
                        <button
                          className="text-gray-900 dark:text-gray-100 font-medium text-left hover:underline focus:outline-none"
                          onClick={() => router.push(`/search/${encodeURIComponent(item.query)}/`)}
                        >
                          {item.query}
                        </button>
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </MainLayout>
  );
}
