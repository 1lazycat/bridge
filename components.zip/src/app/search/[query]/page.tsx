"use client";

import React from "react";
import { useParams } from "next/navigation";
import ClientSearchPage from "@/components/search/client-search-page";

// Mock search result type
interface SearchResult {
  id: string;
  title: string;
  content: string;
  source: {
    name: string;
    url: string;
    favicon: string;
  };
}

interface SourceReference {
  id: string;
  name: string;
  url: string;
  favicon: string;
  description?: string;
}

export default function SearchResultsPage() {
  const params = useParams();
  const query = typeof params.query === 'string' ? params.query :
                Array.isArray(params.query) ? params.query[0] : 'unknown';

  return <ClientSearchPage query={query} />;
}
