import React from "react";
import MainLayout from "@/components/layout/main-layout";
import { LayoutGrid } from "lucide-react";
import Footer from "@/components/footer";

export default function SpacesPage() {
  return (
    <MainLayout>
      <div className="flex flex-col min-h-screen">
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center mb-6">
            <LayoutGrid size={24} className="mr-3 text-perplexity-teal" />
            <h1 className="text-3xl font-semibold">Spaces</h1>
          </div>

          <div className="flex flex-col items-center justify-center py-32">
            <div className="text-center">
              <h2 className="text-2xl font-semibold mb-4">Coming Soon</h2>
              <p className="text-gray-600 max-w-lg">
                This is a placeholder page for the Spaces feature. In the full implementation,
                this would show personalized collections and collaborative spaces.
              </p>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </MainLayout>
  );
}
