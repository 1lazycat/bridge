import OpenAI from 'openai';

// Initialize OpenAI client with better error handling
const getOpenAIClient = () => {
  // Check if we have an API key
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey || apiKey === 'your_openai_api_key_here') {
    // Return null if no valid API key
    console.warn('OpenAI API key not found. Using mock search responses instead.');
    return null;
  }

  // Create client if we have a valid key
  return new OpenAI({
    apiKey,
    dangerouslyAllowBrowser: true,
  });
};

// Safely create the client
const openai = getOpenAIClient();

export interface SearchResponse {
  answer: string;
  sources: {
    id: string;
    name: string;
    url: string;
    favicon: string;
    description?: string;
  }[];
}

// Generate a search response using the OpenAI API with streaming
export async function generateStreamingSearchResponse(
  query: string,
  onChunk: (chunk: string) => void,
  onComplete: (fullResponse: SearchResponse) => void
) {
  // If no API client, fall back to mock responses
  if (!openai) {
    generateMockStreamingSearchResponse(query, onChunk, onComplete);
    return;
  }

  try {
    const stream = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an AI search assistant that provides helpful, accurate, and detailed answers.
          For each query, provide a comprehensive answer, focusing on being informative and educational.
          Include relevant sources of information, including website names, URLs, and brief descriptions.`
        },
        {
          role: "user",
          content: query
        }
      ],
      temperature: 0.7,
      stream: true,
    });

    let fullText = '';

    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content || '';
      if (content) {
        fullText += content;
        onChunk(content);
      }
    }

    // Mock sources for demonstration
    const sources = [
      {
        id: "1",
        name: "wikipedia.org",
        url: `https://www.wikipedia.org/wiki/${query.split(' ').join('_')}`,
        favicon: "https://ext.same-assets.com/2181308295/1218878156.png",
        description: `Information about ${query} from Wikipedia`,
      },
      {
        id: "2",
        name: "scholar.google.com",
        url: "https://scholar.google.com/",
        favicon: "https://ext.same-assets.com/1798230729/1218878156.png",
        description: `Academic research on ${query}`,
      },
      {
        id: "3",
        name: "news.google.com",
        url: "https://news.google.com/",
        favicon: "https://ext.same-assets.com/3515937045/3120916060.png",
        description: `Latest news about ${query}`,
      },
    ];

    // When stream is complete, call onComplete with the full response
    onComplete({
      answer: fullText,
      sources
    });
  } catch (error) {
    console.error("Error generating search response:", error);
    // Fall back to mock response
    const mockResponse = generateMockSearchResponse(query);
    onComplete(mockResponse);
  }
}

// Generate a search response using the OpenAI API (non-streaming)
export async function generateSearchResponse(query: string): Promise<SearchResponse> {
  // If no API client, return mock responses
  if (!openai) {
    return generateMockSearchResponse(query);
  }

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are an AI search assistant that provides helpful, accurate, and detailed answers.
          For each query, provide a comprehensive answer, focusing on being informative and educational.
          Include relevant sources of information, including website names, URLs, and brief descriptions.`
        },
        {
          role: "user",
          content: query
        }
      ],
      temperature: 0.7,
    });

    // Mock sources for now
    const sources = [
      {
        id: "1",
        name: "wikipedia.org",
        url: `https://www.wikipedia.org/wiki/${query.split(' ').join('_')}`,
        favicon: "https://ext.same-assets.com/2181308295/1218878156.png",
        description: `Information about ${query} from Wikipedia`,
      },
      {
        id: "2",
        name: "scholar.google.com",
        url: "https://scholar.google.com/",
        favicon: "https://ext.same-assets.com/1798230729/1218878156.png",
        description: `Academic research on ${query}`,
      },
      {
        id: "3",
        name: "news.google.com",
        url: "https://news.google.com/",
        favicon: "https://ext.same-assets.com/3515937045/3120916060.png",
        description: `Latest news about ${query}`,
      },
    ];

    return {
      answer: response.choices[0]?.message?.content || "No answer found",
      sources
    };
  } catch (error) {
    console.error("Error generating search response:", error);
    return generateMockSearchResponse(query);
  }
}

// Function to simulate streaming search when API key isn't available
export function generateMockStreamingSearchResponse(
  query: string,
  onChunk: (chunk: string) => void,
  onComplete: (fullResponse: SearchResponse) => void
) {
  // Create a fake detailed response based on the query
  const answer = `${query} is a complex topic with many facets to explore.

  In general, it involves several key concepts and ideas that have evolved over time. Experts in the field have conducted extensive research and published numerous papers on this subject.

  When analyzing ${query}, it's important to consider both historical context and modern applications. Several landmark studies have demonstrated significant findings that continue to influence our understanding today.

  Recent advancements have led to new methodologies and approaches, particularly in the last decade. Organizations worldwide are implementing these discoveries to improve efficiency and outcomes.

  The future of ${query} looks promising, with emerging technologies enabling faster progress and more sophisticated solutions than ever before.`;

  // Mock sources
  const sources = [
    {
      id: "1",
      name: "wikipedia.org",
      url: `https://www.wikipedia.org/wiki/${query.split(' ').join('_')}`,
      favicon: "https://ext.same-assets.com/2181308295/1218878156.png",
      description: `Information about ${query} from Wikipedia`,
    },
    {
      id: "2",
      name: "scholar.google.com",
      url: "https://scholar.google.com/",
      favicon: "https://ext.same-assets.com/1798230729/1218878156.png",
      description: `Academic research on ${query}`,
    },
    {
      id: "3",
      name: "news.google.com",
      url: "https://news.google.com/",
      favicon: "https://ext.same-assets.com/3515937045/3120916060.png",
      description: `Latest news about ${query}`,
    },
    {
      id: "4",
      name: "academia.edu",
      url: "https://www.academia.edu/",
      favicon: "https://ext.same-assets.com/2688594803/3120916060.png",
      description: `Research papers about ${query}`,
    },
    {
      id: "5",
      name: "researchgate.net",
      url: "https://www.researchgate.net/",
      favicon: "https://ext.same-assets.com/1713172956/3120916060.png",
      description: `Scientific articles on ${query}`,
    },
  ];

  // Simulate streaming by breaking up the answer into chunks
  const chunks = answer.split(' ');

  let currentText = '';
  let index = 0;

  // Schedule chunks to be streamed at intervals to simulate typing
  const interval = setInterval(() => {
    if (index < chunks.length) {
      const chunk = chunks[index] + ' ';
      currentText += chunk;
      onChunk(chunk);
      index++;
    } else {
      clearInterval(interval);
      // When "stream" is complete, call onComplete
      onComplete({
        answer: currentText,
        sources
      });
    }
  }, 50); // Speed of "typing" - adjust as needed
}

// Function to simulate search when API key isn't available (non-streaming)
export function generateMockSearchResponse(query: string): SearchResponse {
  // Create a fake detailed response based on the query
  const answer = `${query} is a complex topic with many facets to explore.

  In general, it involves several key concepts and ideas that have evolved over time. Experts in the field have conducted extensive research and published numerous papers on this subject.

  When analyzing ${query}, it's important to consider both historical context and modern applications. Several landmark studies have demonstrated significant findings that continue to influence our understanding today.

  Recent advancements have led to new methodologies and approaches, particularly in the last decade. Organizations worldwide are implementing these discoveries to improve efficiency and outcomes.

  The future of ${query} looks promising, with emerging technologies enabling faster progress and more sophisticated solutions than ever before.`;

  // Mock sources
  const sources = [
    {
      id: "1",
      name: "wikipedia.org",
      url: `https://www.wikipedia.org/wiki/${query.split(' ').join('_')}`,
      favicon: "https://ext.same-assets.com/2181308295/1218878156.png",
      description: `Information about ${query} from Wikipedia`,
    },
    {
      id: "2",
      name: "scholar.google.com",
      url: "https://scholar.google.com/",
      favicon: "https://ext.same-assets.com/1798230729/1218878156.png",
      description: `Academic research on ${query}`,
    },
    {
      id: "3",
      name: "news.google.com",
      url: "https://news.google.com/",
      favicon: "https://ext.same-assets.com/3515937045/3120916060.png",
      description: `Latest news about ${query}`,
    },
    {
      id: "4",
      name: "academia.edu",
      url: "https://www.academia.edu/",
      favicon: "https://ext.same-assets.com/2688594803/3120916060.png",
      description: `Research papers about ${query}`,
    },
    {
      id: "5",
      name: "researchgate.net",
      url: "https://www.researchgate.net/",
      favicon: "https://ext.same-assets.com/1713172956/3120916060.png",
      description: `Scientific articles on ${query}`,
    },
  ];

  return {
    answer,
    sources
  };
}
