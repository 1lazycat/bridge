"use client";

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search } from "lucide-react";

interface SearchSuggestionsProps {
  suggestions: string[];
  visible: boolean;
  onSelectSuggestion: (suggestion: string) => void;
}

const SearchSuggestions: React.FC<SearchSuggestionsProps> = ({
  suggestions,
  visible,
  onSelectSuggestion,
}) => {
  if (!visible || suggestions.length === 0) return null;

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
          className="absolute z-10 mt-2 w-full bg-white dark:bg-gray-900 rounded-xl shadow-lg overflow-hidden border border-gray-200 dark:border-gray-700"
          aria-label="Search suggestions"
          role="listbox"
        >
          <ul className="divide-y divide-gray-100 dark:divide-gray-800">
            {suggestions.map((suggestion, index) => (
              <li
                key={index}
                className="hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer text-gray-700 dark:text-gray-300"
                onClick={() => onSelectSuggestion(suggestion)}
                role="option"
                aria-selected="false"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    onSelectSuggestion(suggestion);
                    e.preventDefault();
                  }
                }}
              >
                <div className="px-4 py-3 flex items-center gap-3 focus-visible:bg-gray-100 dark:focus-visible:bg-gray-800 outline-none">
                  <Search size={16} className="flex-shrink-0 text-gray-400 dark:text-gray-500" />
                  <span className="line-clamp-1">{suggestion}</span>
                </div>
              </li>
            ))}
          </ul>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SearchSuggestions;
