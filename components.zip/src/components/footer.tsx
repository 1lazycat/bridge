import React from "react";
import Link from "next/link";

const footerLinks = [
  { name: "Pro", href: "/pro" },
  { name: "Enterprise", href: "/enterprise" },
  { name: "API", href: "/api" },
  { name: "Blog", href: "/hub" },
  { name: "Careers", href: "/hub/careers" },
  { name: "Store", href: "/store" },
  { name: "Finance", href: "/finance" },
];

export default function Footer() {
  return (
    <footer className="border-t mt-auto py-4">
      <div className="container mx-auto px-4 flex flex-wrap items-center justify-center md:justify-between">
        <div className="flex flex-wrap justify-center gap-x-6 mt-2 mb-3 md:my-0">
          {footerLinks.map((link) => (
            <Link
              key={link.name}
              href={link.href}
              className="text-sm text-gray-600 hover:text-perplexity-teal"
            >
              {link.name}
            </Link>
          ))}
        </div>

        <div className="flex items-center justify-center">
          <div className="relative">
            <select
              className="appearance-none bg-transparent pl-3 pr-8 py-1 border rounded-md text-sm"
              defaultValue="English"
            >
              <option value="English">English</option>
              <option value="Spanish">Spanish</option>
              <option value="French">French</option>
              <option value="German">German</option>
              <option value="Japanese">Japanese</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-500">
              <svg
                className="h-4 w-4 fill-current"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
              >
                <path d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
