"use client";

import React from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Home,
  Globe,
  Library,
  Sparkles,
  PanelLeft,
  History,
  Settings,
  LogOut,
  User
} from "lucide-react";
import { PerplexityLogo } from "./logo";
import { Button } from "./ui/button";
import { ThemeToggle } from "./theme/theme-toggle";
import { useAuth } from "@/contexts/auth-context";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const sidebarLinks = [
  {
    name: "Home",
    href: "/",
    icon: Home,
  },
  {
    name: "Discover",
    href: "/discover",
    icon: Globe,
  },
  {
    name: "Spaces",
    href: "/spaces",
    icon: PanelLeft,
  },
  {
    name: "Library",
    href: "/library",
    icon: Library,
  },
];

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout, searchHistory } = useAuth();

  const handleLogout = () => {
    logout();
    router.push("/");
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  return (
    <div className="fixed left-0 top-0 bottom-0 w-60 border-r border-gray-200 bg-white dark:bg-gray-950 dark:border-gray-800 p-4 flex flex-col">
      <div className="mb-8">
        <Link href="/" className="flex items-center gap-2">
          <PerplexityLogo className="h-8 w-8 text-perplexity-teal dark:text-perplexity-teal" />
          <span className="font-bold text-perplexity-darkTeal dark:text-white text-xl">perplexity</span>
        </Link>
      </div>

      <div className="mb-8">
        <Button className="w-full justify-start gap-2 bg-perplexity-teal hover:bg-perplexity-darkTeal text-white">
          <Sparkles size={18} />
          <span>New Thread</span>
          <span className="ml-auto opacity-70 text-xs">K</span>
        </Button>
      </div>

      <nav className="flex-1">
        <ul className="space-y-2">
          {sidebarLinks.map((link) => {
            const isActive = pathname === link.href;

            return (
              <li key={link.name}>
                <Link
                  href={link.href}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                    isActive
                      ? "bg-gray-100 dark:bg-gray-800 text-perplexity-teal"
                      : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                  }`}
                >
                  <link.icon size={20} />
                  <span>{link.name}</span>
                </Link>
              </li>
            );
          })}

          {user && (
            <li>
              <Link
                href="/history"
                className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                  pathname === "/history"
                    ? "bg-gray-100 dark:bg-gray-800 text-perplexity-teal"
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800"
                }`}
              >
                <History size={20} />
                <span>History</span>
                {searchHistory.length > 0 && (
                  <span className="ml-auto bg-gray-200 dark:bg-gray-700 text-xs px-2 py-0.5 rounded-full">
                    {searchHistory.length}
                  </span>
                )}
              </Link>
            </li>
          )}
        </ul>
      </nav>

      <div className="mt-auto flex flex-col gap-2">
        <div className="flex justify-between items-center">
          <ThemeToggle />

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  className="flex-1 ml-2 justify-start items-center gap-2 hover:bg-gray-100 dark:hover:bg-gray-800"
                  aria-label="User menu"
                >
                  <Avatar className="h-6 w-6">
                    <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                  </Avatar>
                  <span className="text-gray-800 dark:text-gray-200 truncate">
                    {user.name}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer text-red-500" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Logout</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button
              variant="outline"
              className="px-4 py-2 flex-1 ml-2 text-perplexity-teal border-perplexity-teal hover:bg-perplexity-teal/10 dark:text-perplexity-teal dark:border-perplexity-teal"
              onClick={() => router.push("/sign-up")}
            >
              Sign Up
            </Button>
          )}
        </div>

        {!user && (
          <Button
            variant="ghost"
            className="w-full justify-center text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 hover:text-perplexity-teal"
            onClick={() => router.push("/sign-in")}
          >
            Log in
          </Button>
        )}
      </div>
    </div>
  );
}
