"use client";

import React, { useState, useEffect, useRef } from "react";
import { Button } from "./ui/button";
import {
  Globe,
  Sparkles,
  X,
  Search,
  ArrowRight
} from "lucide-react";
import { PerplexityLogo } from "./logo";
import SearchSuggestions from "./search/search-suggestions";
import { useRouter } from "next/navigation";
import { useAuth } from "@/contexts/auth-context";

// Sample search suggestions data
const POPULAR_SEARCHES = [
  "What is artificial intelligence?",
  "How does quantum computing work?",
  "Best practices for cybersecurity",
  "Climate change impacts on agriculture",
  "Recent advancements in machine learning",
  "History of cryptocurrency",
  "How to improve mental health",
  "Latest space exploration missions"
];

interface SearchBoxProps {
  demoQuery?: string;
}

export default function SearchBox({ demoQuery }: SearchBoxProps = {}) {
  const [query, setQuery] = useState("");
  const [showClearButton, setShowClearButton] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  const router = useRouter();
  const { user, searchHistory, addSearchToHistory } = useAuth();

  // Update query when demoQuery changes (for demonstration purposes)
  useEffect(() => {
    if (demoQuery !== undefined) {
      setQuery(demoQuery);
      setShowClearButton(demoQuery.length > 0);
    }
  }, [demoQuery]);

  // Handle click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        searchInputRef.current &&
        !searchInputRef.current.contains(event.target as Node) &&
        suggestionsRef.current &&
        !suggestionsRef.current.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // Filter suggestions based on input and search history
  useEffect(() => {
    if (query.length > 0) {
      // First, get matches from popular searches
      const popularMatches = POPULAR_SEARCHES.filter(item =>
        item.toLowerCase().includes(query.toLowerCase())
      );

      // Then, get matches from user's search history (if logged in)
      let historyMatches: string[] = [];
      if (user && searchHistory.length > 0) {
        historyMatches = searchHistory
          .map(item => item.query)
          .filter(item => item.toLowerCase().includes(query.toLowerCase()));
      }

      // Combine both, remove duplicates, and limit to 10 suggestions
      const combinedSuggestions = Array.from(new Set([...historyMatches, ...popularMatches])).slice(0, 8);

      setSuggestions(combinedSuggestions);
      setShowSuggestions(combinedSuggestions.length > 0);
    } else {
      setSuggestions([]);
      setShowSuggestions(false);
    }
  }, [query, user, searchHistory]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setQuery(value);
    setShowClearButton(value.length > 0);
  };

  const clearSearch = () => {
    setQuery("");
    setShowClearButton(false);
    setShowSuggestions(false);
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  };

  const handleSelectSuggestion = (suggestion: string) => {
    setQuery(suggestion);
    setShowSuggestions(false);
    setShowClearButton(true);
  };

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (query.trim()) {
      // Add to search history if user is logged in
      if (user) {
        addSearchToHistory(query);
      }

      // Navigate to search results page with the query
      router.push(`/search/${encodeURIComponent(query)}/`);
    }
  };

  const handleFocus = () => {
    if (query.length > 0 && suggestions.length > 0) {
      setShowSuggestions(true);
    }
  };

  return (
    <div className="relative w-full max-w-3xl mx-auto" ref={suggestionsRef}>
      <form onSubmit={handleSearch} className="relative">
        <div className="flex items-center w-full bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-full shadow-sm hover:shadow-md transition-shadow overflow-hidden">
          <div className="flex-1 relative">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400 dark:text-gray-500" />
            </div>
            <input
              ref={searchInputRef}
              type="text"
              value={query}
              onChange={handleInputChange}
              onFocus={handleFocus}
              placeholder="Ask anything..."
              className="w-full pl-10 pr-12 py-3 outline-none text-gray-800 dark:text-gray-200 placeholder-gray-400 dark:placeholder-gray-500 bg-transparent"
              aria-label="Search input"
            />
            {showClearButton && (
              <button
                type="button"
                onClick={clearSearch}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                aria-label="Clear search"
              >
                <X size={18} />
              </button>
            )}
          </div>
          <div className="flex items-center">
            <button
              type="button"
              className="border-l border-gray-200 dark:border-gray-700 px-3 h-full py-3 text-gray-500 dark:text-gray-400 hover:text-perplexity-teal dark:hover:text-perplexity-teal"
              aria-label="Globe search"
            >
              <Globe size={18} />
            </button>
            <Button
              type="submit"
              className="rounded-full m-1 px-4 py-1.5 h-9 bg-perplexity-teal hover:bg-perplexity-darkTeal focus:ring-2 focus:ring-offset-2 focus:ring-perplexity-teal dark:focus:ring-offset-gray-900"
              aria-label="Search"
            >
              <span className="flex items-center gap-2 text-sm">
                <Sparkles size={16} />
                <span>Auto</span>
              </span>
            </Button>
          </div>
        </div>
      </form>

      {/* Search suggestions */}
      <div className="relative">
        <SearchSuggestions
          suggestions={suggestions}
          visible={showSuggestions}
          onSelectSuggestion={handleSelectSuggestion}
        />
      </div>
    </div>
  );
}
