"use client";

import React, { createContext, useState, useContext, useEffect } from "react";

type User = {
  id: string;
  name: string;
  email: string;
  avatar?: string;
};

type SearchHistoryItem = {
  id: string;
  query: string;
  timestamp: number;
};

interface AuthContextType {
  user: User | null;
  searchHistory: SearchHistoryItem[];
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  logout: () => void;
  addSearchToHistory: (query: string) => void;
  clearSearchHistory: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize user from localStorage
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    const storedSearchHistory = localStorage.getItem("searchHistory");

    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }

    if (storedSearchHistory) {
      setSearchHistory(JSON.parse(storedSearchHistory));
    }

    setIsLoading(false);
  }, []);

  // Save search history to localStorage whenever it changes
  useEffect(() => {
    if (user && searchHistory.length > 0) {
      localStorage.setItem("searchHistory", JSON.stringify(searchHistory));
    }
  }, [user, searchHistory]);

  const login = async (email: string, password: string) => {
    // In a real app, you would validate with a server
    // For demo, we'll just simulate a login
    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Create a fake user
      const newUser = {
        id: "user_" + Date.now(),
        name: email.split("@")[0],
        email: email,
      };

      // Save to localStorage
      localStorage.setItem("user", JSON.stringify(newUser));
      setUser(newUser);

      return Promise.resolve();
    } catch (error) {
      return Promise.reject(error);
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, password: string) => {
    // In a real app, you would register with a server
    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Create a new user
      const newUser = {
        id: "user_" + Date.now(),
        name,
        email,
      };

      // Save to localStorage
      localStorage.setItem("user", JSON.stringify(newUser));
      setUser(newUser);

      return Promise.resolve();
    } catch (error) {
      return Promise.reject(error);
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("user");
    setUser(null);
  };

  const addSearchToHistory = (query: string) => {
    if (!user) return;

    const newSearchItem = {
      id: `search_${Date.now()}`,
      query,
      timestamp: Date.now(),
    };

    // Add to the beginning of the array and limit to 20 items
    const updatedHistory = [newSearchItem, ...searchHistory].slice(0, 20);
    setSearchHistory(updatedHistory);
  };

  const clearSearchHistory = () => {
    setSearchHistory([]);
    localStorage.removeItem("searchHistory");
  };

  const value = {
    user,
    searchHistory,
    isLoading,
    login,
    register,
    logout,
    addSearchToHistory,
    clearSearchHistory,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
